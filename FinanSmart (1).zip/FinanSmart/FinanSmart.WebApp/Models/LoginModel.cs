﻿namespace FinanSmart.WebApp.Models
{
    public class LoginModel
    {
        string PrimeiroNome { get; set; }
        string Password {get; set; }
    }
}
