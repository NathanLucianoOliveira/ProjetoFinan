﻿namespace FinanSmart.WebApp.Models
{
    public class CadastroModel
    {
        public string PrimeiroNome { get; set; }
        public string Sobrenome { get; set; }
        public string Email { get; set; }
        public string CPF { get; set; }
        public string Senha { get; set; }

    }
}
