﻿using FinanSmart.Dominio.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinanSmart.Dominio.Interface.Serviços
{
    public interface ICategoriaServico
    {
        public void AdicionarCategoria(Categoria categoria);
    }
}

