﻿using System;
using System.Collections.Generic;
namespace FinanSmart.Dominio.Entities
{
public class ContaBancaria
{
    public string NumeroConta { get; set; }
    public string TipoConta { get; set; }
    public decimal Saldo { get; set; }
    public DateTime DataAbertura { get; set; }
    public string NomeBanco { get; set; }
            
}
}


